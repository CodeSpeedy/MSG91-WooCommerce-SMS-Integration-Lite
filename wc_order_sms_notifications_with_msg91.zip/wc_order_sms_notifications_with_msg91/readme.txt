Order SMS Notifications With MSG91 For WooCommerce plugin is made to work with WooCommerce. So this is an add-on of WooCommerce plugin.
With this plugin, the WooCommerce buyer will get SMS notification for various types of order status such as after payment complete, after order complete, after order canceled and much more.
The admin also will be able to get SMS notification.
All types of SMS can be easily enabled/disabled from the options panel that is under WooCommerce > Order Notifications.
This plugin uses MSG91 SMS AIP with transactional route type SMS of MSG91.